/*****************************************************************
* This file is part of CLUMondo.
*
* CLUMondo is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* any later version.
*
* CLUMondois distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with CLUMondo.  If not, see <http://www.gnu.org/licenses/>.
*
* CLUMondo main calculation loop
* CLUMondo S.1.1
*
* Development:
*	Peter Verburg
*	31.3.2015
*
* All rights: Peter Verburg <peter.verburg@vu.nl>
*
********************************************************************/

#include "../include/globals.h"
#include "../include/clumondomodules.h"
#include "../include/util.h"

#include <cstring>
#include <stdlib.h>
#include <iostream>
#include <time.h>
//#include <dos.h>
//#include <windows.h> 

int main(int argc, char* argv[])
{
	if (argc <= 2) {
		show_usage();
		exit(1);
	}

	g_argc = argc;
	g_argv = argv;

	// Convert command line switches to global state variables
	std::strcpy(demd, argv[1]);
	std::strcpy(park, argv[2]);


	if (argc > 3) {
		if (argv[3] == std::string("1")) {
			metamod = 1;
		}
		if (argv[3] == std::string("2")) {
			allprob = 1;
		}
		if (argv[3] == std::string("3")) {
			probmaps = 1;
		}
		if (argv[3] == std::string("4")) {
			probmaps = 2;
		}
	}
	else {
		probmaps = 0; metamod = 0; allprob = 0;
	}

	//bool selectcheck;
	int /*i,*/ stepper, stepsize;

	/*
	pausebutton->Visible = true;
	Image3->Visible = false;
	selectcheck = false;
	if (FileCheckon1->Checked == false)
	checkfile = 0;
	for (int i = 0; i < FileListBox2->Items->Count; i++)
	{
	if (FileListBox2->Selected[i])
	selectcheck = true;
	}
	if ((selectcheck == false) && (ParamCount() < 2))
	bbar->SimpleText = "select demand";
	if ((selectcheck == false) && (ParamCount() > 1))
	{
	std::strcpy(demd, ParamStr(1).c_str());
	selectcheck = true;
	}
	*/
	/*
	if (g_argc > 1) {
	std::strcpy(demd, argv[1]);
	//selectcheck = true;
	}
	*/

	/*
	if (selectcheck == true)
	{
	selectcheck = false;
	for (i = 0; i < FileListBox1->Items->Count; i++)
	{
	if (FileListBox1->Selected[i])
	selectcheck = true;
	}
	if ((selectcheck == false) && (ParamCount() < 2))
	bbar->SimpleText = "select region";
	if ((selectcheck == false) && (ParamCount() > 1))
	{
	std::strcpy(park, ParamStr(2).c_str());
	if (ParamCount() > 2)
	{
	if (ParamStr(3) == "1")
	metamod = 1;
	if (ParamStr(3) == "2")
	allprob = 1;
	if (ParamStr(3) == "4")
	probmaps = 2;
	if (ParamStr(3) == "3")
	probmaps = 1;
	if (ParamStr(4) == "beep")
	Beep(1000, 500);
	}
	selectcheck = true;
	checkfile = 0;

	}
	}

	if (selectcheck == true)
	{
	BitBtn1->Visible = true;
	for (int i = 0; i < FileListBox1->Items->Count; i++)	 /* show list of variables in box 1: Area restrictions* /
	{
	if (FileListBox1->Selected[i])
	std::strcpy(park, FileListBox1->Items->Strings[i].c_str());
	}
	for (i = 0; i < FileListBox2->Items->Count; i++)		 /* show list of demand files in box 2* /
	{
	if (FileListBox2->Selected[i])
	std::strcpy(demd, FileListBox2->Items->Strings[i].c_str());
	}
	*/

	year = 0;
	allowmin = 0;
	//YearBar->Position = 0;
	if ((flog = fopen(F_LOG, "w")) == NULL) {
		/* open log-file */
		show_error();
		fclose(flog);
		exit(0);
	}
	//bbar->SimpleText = "Loading...";
	std::cout << "Loading..." << std::endl;
	//Application->ProcessMessages();

	//READING OF ALL INPUT FILES AT START SIMULATIONS
	all_init();				/* read main simulation parameters from input file */
	stepsize = (4000000 / (rncov*rnr*rnc));
	if (stepsize < 1) {
		stepsize = 1;
	}
	if (stepsize > 30) {
		stepsize = 30;
	}
	if (metamod == 1) {
		// In case of a meta-model run determine the minimum value of the sc1gr grids used
		init_allow();
	}
	make_mat();				/* allocates memory for matrices and checks success */
	calc_age();				/* initializes age of land use */
	load_grid();			/* loads explanatory factor grids into memory */
	demand_read();			/* read the demand file for all years */
	load_resistance();      // ���ؾ���ת������ֵ
	load_randomcoefficient();
	load_compcoefficient();
	load_lusconv();
	/*load_Transfer_P();*/
	load_Step();/* read the lusconv matrix with hierarchy of land use systems in terms of demand types */
	if (changeconv != 1) {
		// read the lusmatrix with values of all land use systems in terms of demand types
		load_lusmatrix();
	}
	load_reg();				/* read for the different land use types the regression equations */
	if (influence > 0) {	/* read the regression equations for neighborhoods if option is on */
		load_reg2();
	}
	read_allowed();			/* read the allowed changes between land use types */
	load_region();			/* loads region distribution from regionfile */
	load_LOOP();
	load_Transfer_P();
	if (lusconvmap == 1) {
		// loads the initial composition of the lusconv output maps
		load_ini_output();
	}
	//PerformanceGraph1->Visible = true;

	// Year loop; needs to be connected to start and end
	for (year = 1; year <= (End - start); year++) {
		std::cout << " " << std::endl;
		std::cout << "Now simulating year: " << year << std::endl;
		std::cout << "Updating input information..." << std::endl;

		fprintf(flog, "\n\n\n______   year %d  ______\n", year);

		if (allprob == 0) {
			// Read coverage of land use types for year - 1 from file
			set_oldco();
		}
		if ((locationfactor > 0) && (metamod == 0)) {
			// Read the locationspecific addition if requested
			load_locationfactor();
		}
		if (nochange > 0) {
			// Replace scgr (explanatory factor) files that have changed by current files
			scgr_change();
		}
		if (checkfile == 1) {
			check_file();
		}
		if (changeconv == 1) {
			load_lusmatrix();	   /* read the lusmatrix with values of all land use systems in terms of demand types */
		}
		demand_dir();			  /* loads demands for land use types and determines if demand increases or decreases */
		if (influence > 0) {
			// Calculate neighborhood attributes
			calc_neigh();
			if (influence == 2) {
				write_grid();
				fprintf(flog, "\n influence calculations made");
				fclose(flog);
				//finishbox->ShowModal();
				show_finished();
				exit(0);
			}
		}

		// Initializes iteration parameters
		init_iter();

		std::cout << "Calculating preference maps...." << std::endl;

		calc_reg();			  /* calculate probabilities for each land use type for each grid from regression equations */

		if (probmaps == 1) {
			write_grid();
			loop = 20001;
			year = (End - start);
		}
		std::cout << "Iterating....";
		return_index();
		// Start of iteration for numerical solution
		if ((allprob == 0) && (probmaps < 2)) {
			stepper = 0;
			do {
				loop++;
				std::cout << ".";
				calc_change_ch_re();	// calculates change in land use types
				comp_demand();		// compares demand with allocated land use, adjust elas (iteration parameter)
									// ���������
				//if (loop == 9999 || loop == 10000) {
				//	write_grid();
				//	//Sleep(5000);
				//}

				stepper++;
				if (stepper == stepsize) {
					/*
					if ((maxdiff>demdiffmax) && ((totdiff / (rncov)) < demdiff)) {
					maxdevlabel->Visible = true;
					} else {
					maxdevlabel->Visible = false;
					}
					*/
					stepper = 0;
					//Iterbar->SelEnd = Barpos;
					//PerformanceGraph1->DataPoint(clYellow, (Barpos + 1));
					//PerformanceGraph1->Update();
					//bbar->SimpleText = loop;
					//Application->ProcessMessages();
					if (loop == 5000) {
						calc_reg();
					}
				}

				//if (loop == 2 && year == 1) {
				//	//// ���ת������ֵ
				//	//FILE *f_prob;
				//	//char filenam_prob[20];
				//	//for (int i = 0; i < rncov; i++) {
				//	//	sprintf(filenam_prob, "prob_resi1_%d.%d.asc", i, year);
				//	//	if ((f_prob = fopen(filenam_prob, "w")) == NULL) {
				//	//		fprintf(flog, "\n not able to write file \n");
				//	//		fclose(flog);
				//	//		show_error();
				//	//		exit(0);
				//	//	}
				//	//	if (arcview > 0) {
				//	//		fprintf(f_prob, "ncols    %d\n", rnc);
				//	//		fprintf(f_prob, "nrows    %d\n", rnr);
				//	//		fprintf(f_prob, "xllcorner  %f\n", xllcorner);
				//	//		fprintf(f_prob, "yllcorner  %f\n", yllcorner);
				//	//		fprintf(f_prob, "cellsize   %f\n", cellsize);
				//	//		fprintf(f_prob, "NODATA_value   -9999\n");
				//	//	}
				//	//	for (int j = 0; j < rnr; j++) {
				//	//		for (int k = 0; k < rnc; k++)
				//	//			fprintf(f_prob, "%9.7f\n ", (mat_resi[i][j][k]));
				//	//	}
				//	//	fclose(f_prob);
				//	//}

				//	// �����������
				//	/*FILE *f_comp;
				//	char filenam_comp[20];
				//	for (int i = 0; i < rncov; i++) {
				//		sprintf(filenam_comp, "prob_comp1_%d.%d.asc", i, year);
				//		if ((f_comp = fopen(filenam_comp, "w")) == NULL) {
				//			fprintf(flog, "\n not able to write file \n");
				//			fclose(flog);
				//			show_error();
				//			exit(0);
				//		}
				//		if (arcview > 0) {
				//			fprintf(f_comp, "ncols    %d\n", rnc);
				//			fprintf(f_comp, "nrows    %d\n", rnr);
				//			fprintf(f_comp, "xllcorner  %f\n", xllcorner);
				//			fprintf(f_comp, "yllcorner  %f\n", yllcorner);
				//			fprintf(f_comp, "cellsize   %f\n", cellsize);
				//			fprintf(f_comp, "NODATA_value   -9999\n");
				//		}
				//		for (int j = 0; j < rnr; j++) {
				//			for (int k = 0; k < rnc; k++)
				//				fprintf(f_comp, "%9.7f\n ", (mat_comp[i][j][k]));
				//		}
				//		fclose(f_comp);
				//	}*/

				//	// ���ת������+����
				//	/*FILE *f_allp;
				//	char filenam_allp[20];
				//	for (int i = 0; i < rncov; i++) {
				//		sprintf(filenam_allp, "prob_pn_%d.%d.asc", i, year);
				//		if ((f_allp = fopen(filenam_allp, "w")) == NULL) {
				//			fprintf(flog, "\n not able to write file \n");
				//			fclose(flog);
				//			show_error();
				//			exit(0);
				//		}
				//		if (arcview > 0) {
				//			fprintf(f_allp, "ncols    %d\n", rnc);
				//			fprintf(f_allp, "nrows    %d\n", rnr);
				//			fprintf(f_allp, "xllcorner  %f\n", xllcorner);
				//			fprintf(f_allp, "yllcorner  %f\n", yllcorner);
				//			fprintf(f_allp, "cellsize   %f\n", cellsize);
				//			fprintf(f_allp, "NODATA_value   -9999\n");
				//		}
				//		for (int j = 0; j < rnr; j++) {
				//			for (int k = 0; k < rnc; k++)
				//				fprintf(f_allp, "%9.7f\n ", (mat_allp[i][j][k]));
				//		}
				//		fclose(f_allp);
				//	}*/
				//}

				//write_grid();
			} while ((((totdiff / (rndemand)) > demdiff) && (loop < 100000)) || ((loop < 100000) && (maxdiff > demdiffmax)));   /* end of loop for iteration of allocation on demand */
																																// rndemand�����͵ĸ�����totdiff���������͵����
																																// maxdiff�������Ǹ����
			if ((loop < 100000) && (bottomup == 1)) {
				// Calculate autonomous change */
				autonomous_change();
			}

			if (loop == 100000) {
				unfinished();
			}

			if (loop < 100000) {
				// Update number of time-steps with stable land use type
				calc_age();
			}

			if ((probmaps == 0) && (loop < 100000)) {
				// Write results in output files
				write_grid();
			}
		}
		// END OF ITERATION
		if (allprob == 1) {
			write_grid();
		}
		/*
		Yearprog = (((year)* 100) / (end - start));
		if (loop < 20000)
		YearBar->Position = Yearprog;
		*/
	}
	// END OF YEAR LOOP

	free_mat();				 /* empty memory */
	free_index();
	time_t now = time(NULL);
	struct tm time_struct = *localtime(&now);
	fprintf(flog, "\n\n-- End of simulation at: %2d:%02d:%02d -- \n\n\n", time_struct.tm_hour, time_struct.tm_min, time_struct.tm_sec);

	fclose(flog);

	system("pause");

}
